VANDALSOFT

Beyond the Next dimension

Important!

All the files must be in the same folder: ...\Beyond the Next Dimension.
Otherwise you will not be able to see the 3D objects in the game.
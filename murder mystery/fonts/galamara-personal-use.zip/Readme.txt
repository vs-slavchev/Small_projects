Hej hej,

Thank's for downloading Galamara - A Signature Brush Typeface.

NOTE:

By installing or using this font, you are agree to the Product Usage Agreement:

- This font is already FULL VERSION and ONLY for PERSONAL USE. NO COMMERCIAL USE ARE ALLOWED!
- For Corporate use you have to purchase Corporate license
- If you need a custom license please contact us at foundry@ibracreative.com

- Any donation are very much appreciated. Paypal account for donation: https://paypal.me/IbraCreative
 
Feel free to visit our store for more amazing fonts: https://ibracreative.com 
Kindly check our instagram for update: @IbraCreative

Warm regards,

IbraCreative
-------------------

BAHASA INDONESIA:

Dengan meng-install font ini, Anda telah mengerti dan menyetujui semua syarat dan ketentuan penggunaan font dibawah ini:

- Font demo ini hanya dapat digunakan untuk keperluan "Personal Use"/kebutuhan pribadi, atau untuk keperluan yang sifatnya tidak "komersil", alias tidak menghasilkan profit atau keuntungan dari hasil memanfaatkan/menggunakan font kami. Baik itu untuk Individu, Agensi Desain Grafis, Percetakan, Distro atau Perusahaan/Korporasi.

- Dengan hanya lisensi "Personal Use", DILARANG KERAS menggunakan atau memanfaatkan font ini untuk keperluan Komersial, baik itu untuk Iklan, Promosi, TV, Film, Video, Motion Graphics, Youtube, Desain kaos distro atau untuk Kemasan Produk (baik fisik maupun digital) atau Media apapun dengan tujuan menghasilkan profit/keuntungan.

- Untuk penggunaan keperluan Perusahaan/Korporasi silakan menggunakan Corporate License.

- Menggunakan font ini dengan lisensi "Personal Use" untuk kepentingan Komersial apapun bentuknya TANPA IZIN dari kami, akan dikenakan biaya CORPORATE LICENSE.

Informasi tentang Lisensi apa yang akan anda perlukan, silahkan menghubungi kami di: ibracreativestudio@gmail.com

Terima kasih.

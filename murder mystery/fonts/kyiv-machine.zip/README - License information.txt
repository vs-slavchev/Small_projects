EN > 

"Kyiv Machine" font (2023) has been created by Lukas Krakora and is free for non-commercial use only.

If you'd like to use the font commercially please contact me at my email krraaa@yahoo.com to get an information about pricing.

This font contains also complete character set of Ukrainian, Belarusian and Russian languages.

I can add any extra characters or customize the font for purchasers of the commercial license.

Any donation from non-commercial users to my Paypal krraaa@yahoo.com is welcome. 

You can find my other fonts on www.typewriterfonts.net 

And my FB page is www.facebook.com/typewriterfonts

Thank you

Lukas Krakora



CZ > 

"Kyiv Machine" font (2023) byl vytvoren Lukasem Krakorou a je volne ke stazeni a pouziti avsak pouze pro nekomercni ucely.

V pripade zameru vyuzit font komercne me prosim kontaktujte na emailu krraaa@yahoo.com a dozvite se cenu.

Font obsahuje i kompletni znakovou sadu pro Ukrajinstinu, Belorustinu i Rustinu.

V pripade potreby mohu zajemcum o komercni licenci pridat k fontu dalsi znaky, ci jakkoli upravit existujici.

Jakekoliv financni prispevky od nekomercnich uzivatelu na muj Paypal krraaa@yahoo.com jsou vitany.

Me dalsi fonty naleznete na www.typewriterfonts.net

Take muzete navstivit mou FB stranku www.facebook.com/typewriterfonts

Diky

Lukas Krakora

			 Egg hunt

	 		 a game by
			VANDALSOFT 

 In this easter game you are an easter bunny and you
have to compete with the dog to collect more eggs!

There are 8 different eggs;
the backgroung song is made by Vandalsoft and is called
Good morning due to lack of a better name;
the bunny and dog sprites are from Moosader.com.

release date: 12.04.2012

 The game was made with C++ and the Allegro library.

 Here is our website addres:
vandalsoft.goodluckwith.us